import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarTrigger,
} from "@/components/ui/menubar";
import { ModeToggle } from "@/components/theme-switcher";
import { ArrowDown, Menu } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function Home() {
  return (
    <ScrollArea className="snap-mandatory snap-y h-screen overflow-auto">
      <div className="snap-center flex flex-col w-screen h-screen font-[family-name:var(--font-geist-sans)]">
        <main className="h-full flex flex-col my-2">
          <div className="flex items-center mx-4 gap-3">
            <h1 className="scroll-m-20 text-xl font-bold tracking-tight mr-auto">
              compqueue
            </h1>
            <ModeToggle className="" />
            <Menubar className="p-0">
              <MenubarMenu>
                <MenubarTrigger className="py-0 h-full">
                  <Menu className="w-4 h-4" />
                </MenubarTrigger>
                <MenubarContent align="end" className="mx-2 p-1">
                  <MenubarItem className="sm:hidden">Login</MenubarItem>
                  <MenubarItem>Button</MenubarItem>
                </MenubarContent>
              </MenubarMenu>
            </Menubar>
            <Button variant={"outline"} className="hidden sm:flex">
              Login
            </Button>
          </div>
          <div className="flex items-center justify-center mx-4 gap-4 grow m-4">
            <Input
              placeholder="Enter an address"
              className="max-w-lg min-w-3 w-[80vw]"
            ></Input>
            <Button className="h-auto" variant={"outline"}>
              Start
            </Button>
          </div>
        </main>
        <footer className="h-[50px] flex justify-center">
          <ArrowDown className="w-5 h-5"></ArrowDown>
        </footer>
      </div>
      <div
        id="section2"
        className="snap-center flex items-center justify-center w-screen h-screen font-[family-name:var(--font-geist-sans)]"
      >
        <h3 className="scroll-m-20 text-2xl font-semibold tracking-tight">
          Coming Soon
        </h3>
      </div>
    </ScrollArea>
  );
}
